# Testing Fast R-CNN models on Foggy Driving

1. Clone the [Fast R-CNN][fastrcnn] repository into a directory we will denote by `FRCN_ROOT`.
2. Follow exactly the steps for the full [Fast R-CNN installation][fastrcnnvocdevkit] which requires the **PASCAL VOCdevkit**. This will, inter alia, create a directory `FRCN_ROOT/data/VOCdevkit2007`.
3. Copy the zip file `fast-rcnn-foggy.zip`, in which this readme file is contained, under `FRCN_ROOT` and unzip it through `unzip -o fast-rcnn-foggy.zip` to update the Fast R-CNN repo for testing on Foggy Driving.
   ```
   cp fast-rcnn-foggy.zip ${FRCN_ROOT}
   cd ${FRCN_ROOT}
   unzip -o fast-rcnn-foggy.zip
   ```
4. Download the **current** Foggy Driving package from our [website][sfsu_synthetic] (earlier versions won't work out of the box with Fast R-CNN) and unpack it into a directory we will denote by `path/to/Foggy_Driving`, so that e.g. the RGB images of the dataset are under `path/to/Foggy_Driving/leftImg8bit`. Create a link to Foggy Driving in the VOCdevkit subdirectory of Fast R-CNN via
   ```
   cd ${FRCN_ROOT}/data/VOCdevkit2007
   ln -s path/to/Foggy_Driving
   ```
6. Test the pre-trained Fast R-CNN models which are presented in the paper and are available at our [website][sfsu_synthetic] by using properly adjusted versions of their accompanying `test_script_template.sh` files.


### License

This software is derived from the [Fast R-CNN][fastrcnn] software and is made available under the same MIT License as Fast R-CNN, which is contained in the attached file LICENSE_foggy.txt


### Contact

Please feel free to contact us with any questions or comments:

Christos Sakaridis
csakarid@vision.ee.ethz.ch
https://people.ee.ethz.ch/~csakarid/SFSU_synthetic

[sfsu_synthetic]: <https://people.ee.ethz.ch/~csakarid/SFSU_synthetic>
[fastrcnn]: <https://github.com/rbgirshick/fast-rcnn>
[fastrcnnvocdevkit]: <https://github.com/rbgirshick/fast-rcnn#beyond-the-demo-installation-for-training-and-testing-models>
